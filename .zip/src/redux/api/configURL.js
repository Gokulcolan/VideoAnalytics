export const ADMIN_BASE_URL = process.env.REACT_APP_ADMIN_BASE_URL
  ? process.env.REACT_APP_ADMIN_BASE_URL
  : "";