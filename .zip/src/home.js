// // src/home.js
// import React, { useEffect, useState } from "react";
// import logo from "./assets/tvs-lucas-logo.png";
// import CommonDropdown from "./components/common/commonDropDown";
// import { Grid, Typography } from "@mui/material";
// import DateRangeIcon from "@mui/icons-material/DateRange";
// import AccessTimeIcon from "@mui/icons-material/AccessTime";

// const Home = () => {
//   const [currentDateTime, setCurrentDateTime] = useState(new Date());
//   const [selectedValue, setSelectedValue] = useState("");

//   const options = [
//     { value: 10, label: "Ten" },
//     { value: 20, label: "Twenty" },
//     { value: 30, label: "Thirty" },
//   ];

//   useEffect(() => {
//     const timer = setInterval(() => {
//       setCurrentDateTime(new Date());
//     }, 1000);
//     return () => clearInterval(timer); // Clean up the interval on component unmount
//   }, []);

//   const formatDate = (date) => {
//     return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
//   };

//   const formatTime = (date) => {
//     return date.toLocaleTimeString();
//   };

//   const handleOpen = () => {
//     // dispatch(partNumberApi());
//     // axios.get("http://127.0.0.1:5000/part_number").then((res) => {
//     //   console.log(res, "demo");
//     // });
//   };

//   return (
//     <div>
//       <div className="topBar">
//         <div className="container-fluid">
//           <div className="row">
//             <div className="col-3 ">
//               <img src={logo} alt="Logo" className="img-fluid" />
//             </div>
//             <div className="col-4">
//               <div className="row">
//                 <div className="col-6 ">
//                   <CommonDropdown
//                     id="age-dropdown"
//                     label="Part Number"
//                     options={options}
//                     value={selectedValue}
//                     onOpen={handleOpen}
//                     customChange={setSelectedValue}
//                   />
//                 </div>
//                 <div className="col-6 ">
//                   <CommonDropdown
//                     id="variety-dropdown"
//                     label="Variety"
//                     options={options}
//                     value={selectedValue}
//                     customChange={setSelectedValue}
//                   />
//                 </div>
//               </div>
//             </div>
//             <div className="col-2">&nbsp;</div>
//             <div className="col-3">
//               <div className="counts">
//                 <Grid
//                   container
//                   direction="column"
//                   alignItems="center"
//                   spacing={1}
//                 >
//                   <Grid item>
//                     <Grid container alignItems="center">
//                       <DateRangeIcon />
//                       <Typography style={{ marginLeft: 8 }}>
//                         {formatDate(currentDateTime)}
//                       </Typography>

//                     </Grid>
//                     <Grid container alignItems="center">
//                       <AccessTimeIcon />
//                       <Typography style={{ marginLeft: 8 }}>
//                         {formatTime(currentDateTime)}
//                       </Typography>
//                     </Grid>
//                   </Grid>

//                 </Grid>
//                 {/* <h6>Total Counts: 0</h6> */}
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//       <div className="videoProcessing">
//         <div className="row">
//           <div className="col-9">
//             <h5>Display Video here</h5>
//           </div>
//           <div className="col-3">
//             <h4 className="headingColour">sop compliance</h4>
//             <div className="partsList">
//               <p>Parts 1</p>
//               <p>Parts 2</p>
//               <p>Parts 3</p>
//               <p>Parts 4</p>
//               <p>Parts 5</p>
//               <p>Parts 6</p>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Home;

import React, { useEffect, useState } from "react";
import logo from "./assets/tvs-lucas-logo.png";
import CommonDropdown from "./components/common/commonDropDown";
import DateRangeIcon from "@mui/icons-material/DateRange";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import VerifiedIcon from "@mui/icons-material/Verified";
import CancelIcon from "@mui/icons-material/Cancel";

const Home = () => {
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const [selectedValue, setSelectedValue] = useState("");

  const options = [
    { value: 10, label: "Ten" },
    { value: 20, label: "Twenty" },
    { value: 30, label: "Thirty" },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDate = (date) => {
    return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString();
  };

  const handleOpen = () => {
    // dispatch(partNumberApi());
    // axios.get("http://127.0.0.1:5000/part_number").then((res) => {
    //   console.log(res, "demo");
    // });
  };

  return (
    <div>
      <div className="topBar">
        <div className="container-fluid">
          <div className="row">
            <div className="col-4">
              <img src={logo} alt="Logo" className="img-fluid" />
            </div>
            <div className="col-4">
              <div className="row">
                <div className="col-6">
                  <CommonDropdown
                    id="age-dropdown"
                    label="Part Number"
                    options={options}
                    value={selectedValue}
                    onOpen={handleOpen}
                    customChange={setSelectedValue}
                  />
                </div>
                <div className="col-6">
                  <CommonDropdown
                    id="age-dropdown"
                    label="Variety"
                    options={options}
                    value={selectedValue}
                    customChange={setSelectedValue}
                  />
                </div>
              </div>
            </div>
            <div className="col-4">
              <div className="dateandtime">
                <h6 style={{ marginRight: "25px" }}>
                  <DateRangeIcon
                    style={{ marginRight: "10px", color: "#ff900a" }}
                  />
                  {formatDate(currentDateTime)}
                </h6>
                <h6>
                  <AccessTimeIcon style={{ marginRight: "5px",color: "#ff900a" }} />
                  {formatTime(currentDateTime)}
                </h6>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="videoProcessing">
        <div className="row">
          <div className="col-2">
            <div className="sop-card">
              <h4>Activity Check</h4>
              <div className="partsList">
                <p>Total Counts: 0</p>
              </div>
              <div className="partsList">
                <p style={{ color: "green", fontWeight: "600" }}>
                  Pass Counts: 0
                </p>
              </div>
              <div className="partsList">
                <p style={{ color: "brown" }}>Fail Count: 0</p>
              </div>
              <div>
                <button className="newBtn">Reset</button>
              </div>
            </div>
          </div>
          <div className="col-8">
            <div className="headTitle">
              <h4>GRS PDI Visual Inspection</h4>
            </div>
            <div className="pageContainer">
              <div className="videoContainer">
                <img
                  src="http://192.168.26.52:3000/video_feed"
                  alt="Video Feed"
                  className="videoFeed"
                />
              </div>
            </div>
          </div>
          <div className="col-2">
            <div className="sop-card">
              <h4>Check Points</h4>
              <div className="partsList">
                <p>
                  Parts 1
                  <VerifiedIcon
                    sx={{
                      color: "#00953f",
                      marginLeft: "10px",
                      fontSize: "30px",
                    }}
                  />
                </p>
                <p>
                  Parts 2
                  <CancelIcon
                    sx={{
                      color: "red",
                      marginLeft: "10px",
                      fontSize: "30px",
                    }}
                  />
                </p>
                <p>Parts 3</p>
                <p>Parts 4</p>
                <p>Parts 5</p>
                <p>Parts 6</p>
                <p>Parts 7</p>
                <p>Parts 8</p>
              </div>
            </div>

            <div>
              <h5 style={{ textAlign: "left", marginBottom: "15px" }}>
                Visual Check Result
              </h5>
              <div className="selectBtn">
                <button className="ok">OK</button>
                <button className="notok">NOT OK</button>
              </div>
            </div>
            <br />
            <div className="finalResult">
              <h5 style={{ textAlign: "left", marginBottom: "15px" }}>
                Final Result
              </h5>
              <h5 className="pass">Pass</h5>
            </div>
            <br />
          </div>
        </div>
      </div>
      <div>
        {/* Existing content */}

        <footer className="footer">
          <p>
            All rights reserved. Copyright © 2024 Video Analytics by AI Team.
          </p>
        </footer>
      </div>
    </div>
  );
};

export default Home;
